create definer = root@localhost trigger trigger_setEmplStatus
    before update
    on employee
    for each row
BEGIN
IF (NEW.date_of_dismissal IS NOT NULL)
THEN SET NEW.status = 0;
END IF;
END;


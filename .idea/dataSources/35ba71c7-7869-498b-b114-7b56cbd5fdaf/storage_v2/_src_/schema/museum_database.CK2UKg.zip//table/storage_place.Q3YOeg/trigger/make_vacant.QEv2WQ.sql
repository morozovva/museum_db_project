create definer = root@localhost trigger make_vacant
    before insert
    on storage_place
    for each row
BEGIN
if new.vacant is NULL THEN
Set new.vacant = 0;
END IF;
END;


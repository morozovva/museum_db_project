create definer = root@localhost trigger make_unav
    after update
    on item
    for each row
BEGIN
IF new.cell_number <> old.cell_number THEN
UPDATE storage_place
SET vacant = 0
WHERE cell_number = old.cell_number;
UPDATE storage_place
SET vacant = 1
WHERE cell_number = new.cell_number;
end if;
END;


create definer = root@localhost trigger phone_checker
    after insert
    on employee
    for each row
BEGIN
END;


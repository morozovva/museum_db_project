create definer = root@localhost trigger trigger1_setEmployment
    before insert
    on employee
    for each row
BEGIN
SET NEW.date_of_employment = NOW();
END;


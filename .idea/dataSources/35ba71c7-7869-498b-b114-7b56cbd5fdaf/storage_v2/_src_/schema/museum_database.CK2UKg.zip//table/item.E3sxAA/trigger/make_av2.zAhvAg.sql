create definer = root@localhost trigger make_av2
    after delete
    on item
    for each row
BEGIN
UPDATE storage_place
SET vacant = 0
WHERE cell_number = old.cell_number;
END;


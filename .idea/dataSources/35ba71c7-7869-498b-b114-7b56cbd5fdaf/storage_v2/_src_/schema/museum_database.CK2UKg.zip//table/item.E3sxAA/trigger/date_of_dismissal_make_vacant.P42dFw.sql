create definer = root@localhost trigger date_of_dismissal_make_vacant
    after update
    on item
    for each row
BEGIN
IF (new.date_of_dismissal IS NOT NULL)
THEN UPDATE storage_place
SET vacant = 0
WHERE cell_number = new.cell_number;
END IF;
END;

